# Norsk Økonomi — publisering og revisjon

**Utgave:** 0.2 (12. oktober 2026)  
**Språk:** Norsk (bokmål)  
**Status:** Foreløpig forskningsdelrapport; ikke fagfellevurdert.

## Publiser nettstedet

1. Pakk ut `Norsk_Okonomi_Nettside_Publisering_2026-10-12.zip`.
2. Last opp `index.html` og mappene/filene som følger med, til dokumentroten på ditt nettsted. Eksempel på struktur:

   ```text
   public_html/
     index.html
     Norsk_Okonomi_Forskningsrapport_2026-10-12.md
     LES-MEG.md
     data/
       observasjoner.csv
       kilder.json
   ```
3. Åpne domenet ditt. All interaktivitet kjører lokalt i besøkendes nettleser. Ingen API-nøkkel, database, serverkode, innlogging eller ekstern JavaScript-tjeneste er nødvendig.
4. Ved bruk av GitHub Pages eller Netlify: publiser mappen hvor `index.html` ligger som nettstedets rot. Énfilversjonen `Norsk_Okonomi_Interaktiv_2026-10-12.html` fungerer også ved direkte opplasting/åpning, men om du vil ha en pen rotadresse, gi den navnet `index.html`.

**Merk:** Figurene og scenarioene bruker innebygde dataverdier med statisk datovintage. Tall oppdateres ikke automatisk, og dette bør opplyses om ved publisering. Hver kilde er koblet til en offentlig originalside. Spred ikke eldre utgaver som om de er oppdaterte.

## Hva som ligger i pakken

- `index.html`: Full norsk forskningsrapport, interaktivt datagalleri, hypoteseregister, GPFG-simulator, boligformuestresstest og kildehenvisninger. Kan åpnes direkte uten nettforbindelse; kildelenkene krever nettforbindelse.
- `Norsk_Okonomi_Forskningsrapport_2026-10-12.md`: **Kanonisk rapporttekst**, med sammendrag, metode, funn, begrensninger, testplan og kildeliste.
- `data/observasjoner.csv`: Semikolondelt, UTF-8 med BOM for åpning i norsk regnearkprogram. Tallene har år, enheter, datastatus og kilde-ID.
- `data/kilder.json`: Referanseregister med offentlige kildelenker.
- `kildekode/bygg_publisering.py` og `kildekode/mal_nettside.html`: Kildekode for å regenerere nettsiden fra Markdown. Krever Python med `markdown-it-py` og `beautifulsoup4` under ombygging (ikke for publisering).

## Metodiske grenser

- Dette er **ikke** en ferdig 1970–2026 harmonisert nordisk panelstudie, en registerbasert generasjonsstudie eller en kausal reformutredning. Fremtidige forskningspakker må gjennomføres og analyseres separat.
- **A** betegner beskrivende/administrative kilder, **B** samvariasjon, **C** kausale design under forutsetninger og **D** modellert scenario. D er **ikke** sterkere bevis enn C.
- Simulatorene er konsekvensberegninger under bevisst enkle forutsetninger, ikke prognoser. Oljefondsmodellen utelater blant annet netto petroleumsstrømmer, valutakurs og finanspolitisk tilpasning.
- Offentlig utgiftsandel av **samlet BNP** kan ikke sammenliknes direkte med andel av **Fastlands-BNP**.
- Den opprinnelige forskningslisten dekker tolv tråder og åtte generasjonspakker; ikke alle tråder har ferdige empiriske undersøkelser.

## Oppdateringer og kvalitetssikring

1. Oppdater kanonisk Markdown med nye dokumenterte funn og kilde-ID-er; registrer eventuelle revisjoner av SSB/OECD-data.
2. Oppdater tallblokken i `bygg_publisering.py` (vedlikehold helst observasjoner i ekstern datakilde i neste utgave). Ny kilde skal spores i `data/kilder.json`.
3. Regenerer `index.html`; kontroller at kapittellenker, kildeankre, scenarioer og mobilutgave fungerer.
4. Dokumenter endringer i utgave, datagrense, datakilde og metode; arkiver tidligere versjon med dato.
5. Vurder uavhengig faglig gjennomgang før rapporten oppgis som avsluttet forskning.

## Tilgjengelighet, opphavsrett og ansvar

Nettstedet bruker semantiske overskrifter, ordinære teksttabeller som supplement til grafer og kontroller med synlige etiketter. Det er ingen skjult sporing. Originalkildene beholder sine egne rettigheter. Denne rapporten har ikke tildelt DOI og er ikke fagfellevurdert. Henvis ved bruk til «Norsk Økonomi, forskningsutgave 0.2, 12.10.2026», med dato for bruk og identifiserbare primærkilder.
