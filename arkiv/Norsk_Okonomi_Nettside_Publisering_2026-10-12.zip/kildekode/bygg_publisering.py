#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bygger norsk, selvstendig forskningsnettside fra kanonisk Markdown.
Kjør: python bygg_publisering.py
Avhengigheter ved ombygging: markdown-it-py og beautifulsoup4.
Selve nettsiden krever ingen avhengigheter, API eller database.
"""
from __future__ import annotations
import re, csv, json, html, unicodedata, shutil, zipfile
from pathlib import Path
from datetime import date
from bs4 import BeautifulSoup, NavigableString
from markdown_it import MarkdownIt

ROOT = Path(__file__).resolve().parent
DATE = '2026-10-12'
MD = ROOT / f'Norsk_Okonomi_Forskningsrapport_{DATE}.md'
SITE = ROOT / 'nettside'
DATA = SITE / 'data'
DATA.mkdir(parents=True, exist_ok=True)
text = MD.read_text(encoding='utf-8')
assert text.startswith('---\n')
body = text.split('\n---\n', 1)[1].lstrip()

sources=[]
for line in body.splitlines():
    match=re.match(r'<a id="k(\d\d)"></a>\s+\*\*K\d\d\s+—\s+(.+?)\*\*\s*(.*)', line)
    if match:
        key=f'K{match.group(1)}'
        org=match.group(2)
        details=match.group(3)
        urls=[m.rstrip(',.') for m in re.findall(r'https?://[^\s]+',details)]
        sources.append({'id':key, 'opphav':org, 'referanse':details, 'url':urls, 'kontrollert':'2026-10-12'})
assert len(sources)==22, f'forventet 22 kilder, fant {len(sources)}'
smap={x['id']: x for x in sources}
(DATA/'kilder.json').write_text(json.dumps({'rapportversjon':'0.2', 'kildedato':DATE, 'kilder':sources},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

obs=[]
def put(serie, tema, indikator, periode, gruppe, verdi, enhet, kilde, status, note=''):
    obs.append({'serie':serie,'tema':tema,'indikator':indikator,'periode':str(periode),'gruppe':gruppe,
        'verdi':str(verdi),'enhet':enhet,'kilde_id':kilde,'datastatus':status,'merknad':note})

for year, value in [(2016,7510),(2017,8488),(2018,8256),(2019,10088),(2020,10914),(2021,12340),(2022,12429),(2023,15757),(2024,19742),(2025,21268)]:
    put('fond_historikk','Statsfinanser','SPU – markedsverdi ved utgangen av året',year,'Norge',value,'mrd. NOK','K06','Regnskapsverdi','Nominell NOK; ikke inflasjonskorrigert; variasjoner inkluderer valuta og fondstilførsler')
put('fond_historikk_2026','Statsfinanser','SPU – markedsverdi ved utgangen av 1. halvår','2026-H1','Norge',22683,'mrd. NOK','K06','Halvårsobservasjon','Ikke sammenlikn som fullført år')
for country,v in [('Norge',40.2),('OECD',34.1),('Danmark',45.2),('Sverige',41.4),('Finland',42.2)]:
    put('skatt_2024','Skatt','Skatteinntekter i prosent av samlet BNP',2024,country,v,'prosent','K17','Sammenliknbar OECD-statistikk','Målt mot samlet BNP, ikke Fastlands-BNP')
put('skatt_2000','Skatt','Skatteinntekter i prosent av samlet BNP',2000,'Norge',41.8,'prosent','K17','Historisk OECD-serie')
for age,group,val in [(25,'Øverste 2 % foreldre',50),(25,'Nederste 25 % foreldre',20),(30,'Nederste 25 % foreldre',42),(30,'Nederste 25 % – Oslo/Bærum',36),(30,'Nederste 25 % – andre kommuner',46)]:
    put('boligeierskap_ung','Generasjoner','Registrert boligformue innen oppgitt alder',f'alder-{age}',group,val,'prosent','K08','Kohortanalyse','Årskull født 1988–1993, bosatt Norge 2005 og 2023')
for year,main,total,hours in [(2024,0.6,1.4,0.5),(2025,1.7,1.1,0.4)]:
    put('fastlandsvekst','Vekst','Fastlands-BNP, volumendring',year,'Norge',main,'prosent årlig','K01','Foreløpig nasjonalregnskap')
    put('totalvekst','Vekst','Samlet BNP, volumendring',year,'Norge',total,'prosent årlig','K01','Foreløpig nasjonalregnskap')
    put('timeverk_hele','Arbeid','Utførte timeverk, hele økonomien',year,'Norge',hours,'prosent årlig','K01','Foreløpig nasjonalregnskap')
put('fastland_q2','Vekst','Fastlands-BNP, sesongjustert kvartalsvekst','2026-K2','Norge',0.3,'prosent fra foregående kvartal','K01','Foreløpig','Ikke sammenlikn direkte med årlige vekstrater')
for country,val in [('Norge',49.6),('OECD',42.6)]:
    put('offutgift_2024','Offentlig sektor','Offentlige utgifter i prosent av samlet BNP',2024,country,val,'prosent','K03','OECD-sammenlikning','Denne figuren benytter total-BNP i nevner i begge observasjoner')
put('offjobber','Offentlig sektor','Andel jobbforhold i offentlig forvaltning','2025-K2','Norge',33.5,'prosent av jobbforhold','K18','SSB register','Ikke andel personer eller årsverk')
for cat, val in [('Primærbolig',8245.797),('Sekundærbolig',913.257),('All realkapital',9937.819),('Brutto finanskapital',4841.252),('Samlet bruttoformue',14779.072),('Samlet gjeld',4598.482),('Beregnet nettoformue',10180.589)]:
    put('formue_2024','Formue',cat,2024,'Husholdninger',val,'mrd. NOK','K07','SSB beregnet markedsverdi','Husholdninger med studenter er utelatt; observasjonene er beholdninger')
put('formue_bolig_andel','Formue','Primær- og sekundærbolig som andel av bruttoformue',2024,'Husholdninger',61.972,'prosent','K07','Egen beregning','(8 245 797 + 913 257)/14 779 072 * 100')
for year,val in [(2015,1.73),(2024,1.44),(2025,1.48)]:
    put('fruktbarhet','Demografi','Samlet fruktbarhetstall',year,'Norge',val,'barn per kvinne','K11','SSB statistikk','Utvalgte år; ikke komplett tidsserie')
for year,val in [(2024,54013),(2025,55401)]:
    put('fodte','Demografi','Levendefødte',year,'Norge',val,'barn','K11','SSB statistikk')
for year,val in [(2015,28.9),(2024,30.4),(2025,30.4)]:
    put('førstegangsalder','Demografi','Mors alder ved første fødsel',year,'Norge',val,'år','K11','SSB statistikk','Utvalgte år')
for year,val in [(2025,531),(2026,579)]:
    put('fondsuttak','Statsfinanser','Strukturelt oljekorrigert underskudd, anslag i RNB 2026',year,'Norge',val,'mrd. kroner i 2026-priser','K05','Budsjettanslag','Tall fra samme revisjon, ikke endelige regnskapstall')
put('fondsuttak_bn','Statsfinanser','Strukturelt underskudd som andel av trend-Fastlands-BNP',2026,'Norge',12.6,'prosent','K05','Budsjettanslag')
put('fondsuttak_andel','Statsfinanser','Strukturelt underskudd som andel av SPU-verdi ved inngang',2026,'Norge',2.7,'prosent','K05','Budsjettanslag')
put('budsjettgap','Statsfinanser','Langsiktig finanspolitisk inndekningsbehov, betinget referansebane',2060,'Norge',6.2,'prosent av Fastlands-BNP','K13','Offentlig scenario','Betinget framskriving, ikke prognose')
put('inntekts_gini','Ulikhet','Gini, ekvivalert inntekt etter skatt',2024,'Norge',0.248,'indeks','K07','SSB statistikk')
for group,val in [('Øverste 1 %',21.7),('Nederste 50 %',3.5)]:
    put('formueandel','Ulikhet','Andel samlet beregnet nettoformue',2024,group,val,'prosent','K07','SSB statistikk')
put('gründere','Bedrifter','Personer som etablerte foretak',2024,'Norge',64622,'personer','K14','Foreløpig','Ikke lik nye foretak')
put('foretak_q2','Bedrifter','Nyregistrerte foretak','2026-K2','Norge',17052,'foretak','K15','SSB foreløpig','Kvartalstall, ikke personer som etablerte foretak')
put('fou_2024','Bedrifter','Foretakssektorens egenutførte FoU',2024,'Norge',46.6,'mrd. NOK','K16','SSB FoU-telling')
with (DATA/'observasjoner.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(obs[0].keys()),delimiter=';')
    writer.writeheader();writer.writerows(obs)

markdown=MarkdownIt('commonmark',{'html':True,'typographer':True}).enable('table').enable('strikethrough')
soup=BeautifulSoup(markdown.render(body),'html.parser')

# Bygg stabile interne lenker i hele rapporten; behold faglige K01--K22-kildeankre.
def slugify(s):
    ascii_str=''.join(c for c in unicodedata.normalize('NFKD',s.lower()) if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]+','-',ascii_str).strip('-')[:72]
seen=set()
for tag in soup.find_all(['h1','h2','h3','h4']):
    slug='rapport-'+slugify(tag.get_text())
    base=slug;i=2
    while slug in seen:
        slug=base+'-'+str(i);i+=1
    tag['id']=slug;seen.add(slug)

# Egne henvisningslenker som fungerer også når nettleseren ikke lenkifiserer rene URL-er.
for a in soup.find_all('a',id=re.compile(r'^k\d\d$')):
    source=smap.get(a['id'].upper())
    if not source:continue
    for i,url in enumerate(source['url']):
        link=soup.new_tag('a',href=url)
        link['class']='kilde-ekstern'
        link['target']='_blank';link['rel']='noopener noreferrer'
        link.string='Åpne originalkilde' if len(source['url'])==1 else f'Åpne originalkilde {i+1}'
        a.parent.append(' ')
        a.parent.append(link)

# Formelen vises lesbart uten tredjeparts Javascript-avhengigheter.
for p in soup.find_all('p'):
    if '$$F_{t+1}' in p.get_text():
        formula=soup.new_tag('div');formula['class']='formel'; formula['role']='math'
        formula.append(BeautifulSoup('F<sub>t+1</sub> = F<sub>t</sub> · (1 + r) − U<sub>t</sub> &nbsp;&nbsp; | &nbsp;&nbsp; U<sub>t+1</sub> = U<sub>t</sub> · (1 + g)', 'html.parser'))
        p.replace_with(formula)

# Plasser brede regnskapstabeller i horisontalt rullbare containere.
for tabell in soup.find_all('table'):
    wrapper=soup.new_tag('div');wrapper['class']='tabell-rull';tabell.wrap(wrapper)

# Gjør report-tabs og kapitler navigerbare og søkbare.
chapters=[]
for h in soup.find_all('h2'):
    chapters.append({'id':h['id'],'title':h.get_text(' ',strip=True)})
article=soup.new_tag('article',id='forskningsrapport')
article['class']='rapport-tekst'
head=soup.new_tag('div');head['class']='rapport-fulloverskrift'
# Flytt alle noder fra soup over i artikkelen og pakk kapitler i sections.
children=list(soup.contents)
current=None
for child in children:
    if getattr(child,'name',None)=='h2':
        current=soup.new_tag('section',id='del-'+child.get('id',''))
        current['class']='rapport-kapittel';current['data-overskrift']=child.get_text(' ',strip=True)
        article.append(current)
    (current or article).append(child)
article_html=str(article)

# Forsøk basert på eksplisitt registrete hypoteser; søkeindeksen gjenspeiler rapportens egne formuleringer.
hypotheses=[]
for h in article.find_all('h3'):
    t=h.get_text(' ',strip=True)
    match=re.match(r'^(H\d\d)\s+—\s+(.+)',t)
    if match:
        nextnode=h.find_next_sibling('p')
        if nextnode is None: continue
        p=nextnode.get_text(' ',strip=True)
        def segment(start,end):
            m=re.search(r'\b'+re.escape(start)+r':\s*(.*?)(?=\b'+re.escape(end)+r':|$)',p)
            return m.group(1).strip() if m else ''
        hypothesis=segment('Hypotese','Motforklaring')
        against=segment('Motforklaring','Variabler og test')
        status_m=re.search(r'Status\s*(.*?)(?:\s*Falsifikasjon:|$)',p)
        st=status_m.group(1).strip(' .;') if status_m else 'Ikke ferdig testet'
        hypotheses.append({'id':match.group(1),'tittel':match.group(2), 'hypotese':hypothesis, 'motforklaring':against,'status':st,'ankerkobling':'#'+h['id']})
assert len(hypotheses)==12, f'Fant bare {len(hypotheses)} hypoteser'

# HTML-mal lagres som kildefil ved siden av byggeskriptet.
template=(ROOT/'mal_nettside.html').read_text('utf-8')
subst={
  '@@ARTIKKEL@@':article_html,
  '@@KAPITLER@@': json.dumps(chapters,ensure_ascii=False).replace('<','\\u003c'),
  '@@HYPOTESER@@':json.dumps(hypotheses,ensure_ascii=False).replace('<','\\u003c'),
  '@@KILDER@@':json.dumps(sources,ensure_ascii=False).replace('<','\\u003c'),
  '@@OBSERVASJONER@@':json.dumps(obs,ensure_ascii=False).replace('<','\\u003c'),
  '@@ANTALLOBS@@':str(len(obs)),
}
for key,val in subst.items():
    assert key in template,key
    template=template.replace(key,val)
assert '@@' not in template, 'Uutfylt malvariabel'
(SITE/'index.html').write_text(template,encoding='utf-8')
shutil.copyfile(MD,SITE/MD.name)
shutil.copyfile(ROOT/'LES-MEG.md',SITE/'LES-MEG.md')

# Enkeltfiler for direkte tilgang ved siden av en opplastbar ZIP-pakke.
OUT=ROOT.parent
out_html=OUT/f'Norsk_Okonomi_Interaktiv_{DATE}.html'
out_md=OUT/f'Norsk_Okonomi_Forskningsrapport_{DATE}.md'
shutil.copyfile(SITE/'index.html',out_html)
shutil.copyfile(MD,out_md)
zipf=OUT/f'Norsk_Okonomi_Nettside_Publisering_{DATE}.zip'
with zipfile.ZipFile(zipf,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for file in sorted(SITE.rglob('*')):
        if file.is_file():z.write(file,str(file.relative_to(SITE)))
    z.write(ROOT/'bygg_publisering.py','kildekode/bygg_publisering.py')
    z.write(ROOT/'mal_nettside.html','kildekode/mal_nettside.html')
print(f'Kilder: {len(sources)}; observasjoner: {len(obs)}; hypoteser: {len(hypotheses)}; kapitler: {len(chapters)}')
for file in [MD,out_md,out_html,zipf]:print(file,round(file.stat().st_size/1024,1),'KiB')
